$(document).ready(function(){
	
	$("#my_account").mouseover(function(){
			$(".account_big").show();						 
	}).mouseout(function(){
			$(".account_big").hide();	
	});
	
	
	//侧边导航
	$('.allnav_hover').hover(function(){
		$(this).find('.allnav_head').addClass('allnav_open');
		$(this).find('.allnav_content').show();
	},function(){
		$(this).find('.allnav_head').removeClass('allnav_open');
		$(this).find('.allnav_content').hide();
	});
	$('.Classification_navigation_big li').hover(function(){
		$(this).addClass('selected');
		$(this).find('.i-mc').show();
	},function(){
		$(this).removeClass('selected');
		$(this).find('.i-mc').hide();
	});
	//更新购物车数量
	cartNumber();
		
});

// JavaScript Document

//更新购物车数量

function cartNumber(){
	$.get('/index.php/Home/Cart/cartNumber',function(data){
		if(data.res == 1){
			$('#cart_number').html(data.data);
		} else{
			$('#cart_number').html(0);
		}
	},'json');
};
function AddFavorite(sURL, sTitle){
   try{
       window.external.addFavorite(sURL, sTitle);
   }catch (e){
       try{
           window.sidebar.addPanel(sTitle, sURL, "");
       }catch (e){
           alert("加入收藏失败，请使用Ctrl+D进行添加");
		   return false;
       }
   }
};