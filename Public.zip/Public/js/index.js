// JavaScript Document
$(document).ready(function(){
	//新品上架
	$('#news li').hover(function(){
		$(this).addClass('product-iWrap');
	},function(){
		$(this).removeClass('product-iWrap');
	});
	
	$('#hot li').hover(function(){
		$(this).addClass('product-iWrap');
	},function(){
		$(this).removeClass('product-iWrap');
	});


});

