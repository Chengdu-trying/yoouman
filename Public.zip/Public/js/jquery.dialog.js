/*
* author maga
* 使用art.dialog实现的对话框
* 只提供常用的接口，如果需要使用原生的接口，可以直接参考http://www.planeart.cn/demo/artDialog/_doc/API.html
*/

(function() {

	//对话框内核地址
	var CORE_DIALOG = "/Public/js/jquery.artDialog.core.js?skin=default";
	//对话框样式地址
	var CORE_DIALOG_CSS = "";
	//创建脚本
	var _dialog_script = document.createElement("SCRIPT");
	_dialog_script.src = CORE_DIALOG; 
	_dialog_script.type = "text/javascript";
	//创建样式
	//var dialog_css = document.createElement("LINK");
	//dialog_script.href = CORE_DIALOG_CSS; 
	//dialog_css.type = "text/css";
	//dialog_css.rel = "stylesheet";
	var _dialog_js = document.getElementById("dialog_js");
	//dialog_js.parentNode.insertBefore(dialog_css, dialog_js);
	var _parentNode = _dialog_js.parentNode;
	_parentNode.insertBefore(_dialog_script, _dialog_js);

})();



var shop = shop||{};

//常用消息框,如果需要回调函数，可以设置点击确认后的操作，一般不需要设置，message可以为html代码

shop.msg = function(message, ok_op, cancel_text, cancel_op){
	
	var Obj = {};
	Obj.content = message;
	Obj.fixed = true;
	Obj.lock = true;
	Obj.opacity = 0.23;
	Obj.resize = false;
	Obj.width = 250;
	Obj.height = 90;
	if(typeof(ok_op) == "function"){
		Obj.ok = ok_op;
	}else{
		Obj.ok = true;
	}
	if(cancel_text){
		Obj.cancelVal = cancel_text;
		if(typeof(cancel_op) == "function"){
			Obj.cancel = cancel_op;
		}else{
			Obj.cancel = true;
		}
	}
	art.dialog(Obj);

	//art.dialog({

		//id: 'msg',

		//title: '公告',

		//content: message,

		//width: 220,

		//height: 100,

		//left: '100%',

		//top: '100%',

		//fixed: true,

    	//background: '#000', // 背景色

    	//opacity: 0.23,	// 透明度

		//lock: true,  //锁屏

		//drag: false, //不允许拖动

		//resize: false, //不允许缩放
		
		//cancelVal: cancel_text,

		//确定执行的函数

		//ok: function () {

    		//if(typeof(ok_op) == "function")

				//ok_op();

			//this.close();

        	//return false;

    	//}

	//});

};

shop.msg2 = function(message, ok_text, ok_op, cancel_text, cancel_op){
	
	var Obj = {};
	Obj.content = message;
	Obj.fixed = true;
	Obj.lock = true;
	Obj.opacity = 0.23;
	Obj.resize = false;
	Obj.width = 250;
	Obj.height = 90;
	if(ok_text){
		Obj.okVal = ok_text;
		if(typeof(ok_op) == "function"){
			Obj.ok = ok_op;
		}else{
			Obj.ok = true;
		}
	}
	if(cancel_text){
		Obj.cancelVal = cancel_text;
		if(typeof(cancel_op) == "function"){
			Obj.cancel = cancel_op;
		}else{
			Obj.cancel = true;
		}
	}
	art.dialog(Obj);
};

shop.url = function(url, width, height,callback){

	var width = width?width:480;

	var height = height?height:320;
	
	var Obj = {};
	Obj.fixed = true;
	Obj.lock = true;
	Obj.opacity = 0.23;
	Obj.resize = false;
	Obj.width = width;
	Obj.height = height;
	if(callback){
		Obj.ok = callback;
	}
	
	art.dialog.open(url,Obj);
	/*art.dialog.open(url, {

		fixed: true,

		lock: true,

		opacity: 0.23,

		resize: false,

		width: width,

		height: height

	}); */

};

shop.load = function(url, width, height,callback,title){

	var width = width?width:480;

	var height = height?height:320;
	
	var Obj = {};
	Obj.fixed = true;
	Obj.lock = true;
	Obj.opacity = 0.23;
	Obj.resize = false;
	Obj.width = width;
	Obj.height = height;
	Obj.title = title;
	if(callback){
		Obj.ok = callback;
	}
	
	art.dialog.load(url,Obj);
	/*art.dialog.open(url, {

		fixed: true,

		lock: true,

		opacity: 0.23,

		resize: false,

		width: width,

		height: height

	}); */

};

//其他自定义接口